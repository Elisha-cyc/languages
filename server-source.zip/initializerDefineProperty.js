"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _initializerDefineProperty;
function _initializerDefineProperty(target, property, descriptor, context) {
  if (!descriptor) return;
  Object.defineProperty(target, property, {
    enumerable: descriptor.enumerable,
    configurable: descriptor.configurable,
    writable: descriptor.writable,
    value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
  });
}

//# sourceMappingURL=initializerDefineProperty.js.map
